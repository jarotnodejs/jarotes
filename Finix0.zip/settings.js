// OBEY COMMANDMENTS

global.prefa = ['','!','.',',','🐤','🗿'] //NOT CHANGE
global.owner = ['6289613691894'] //OWNER
global.botname = 'JAROT🦖' //BOT NAME
global.versisc = "5.0.0" //NOT CHANGE
global.baileys1 = require('@whiskeysockets/baileys') //NOT CHANGE
global.creator = "Pann_Ultra" //NOT CHANGE
global.packname = "Sticker By" //OPSIONAL
global.author = "SukiMewing" //OPSIONAL
global.simbol = "" // SIMBOL MENU
global.idCH = "0012345678998765432100@newsletter"
